/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.myjavachatapp;

/**
 *
 * @author Student
 */
public class message {
    

    private String sender; 
    private String recipient;
    private String messageText;

    // Constructor
    public message(String sender, String recipient, String messageText) {
        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    // Display the message
    public void displayMessage() {
        System.out.println("------------------------------------------------");
        System.out.println("Sender: " + sender);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + messageText);

        // Auto reply
        System.out.println("Reply: Message received successfully!");
        System.out.println("------------------------------------------------");
    }

    // Getters
    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }
}

